﻿using Microsoft.AspNetCore.Mvc;
using Proj_faz_1.Models;
using System.Diagnostics;
using Proj_faz_1.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;

namespace Proj_faz_1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Repositories _services;
        private readonly UserManager<IdentityUser> _userManager;
        public HomeController(ILogger<HomeController> logger, Repositories services, UserManager<IdentityUser> user)
        {
            _userManager = user;
            _services = services;
        }

        public async Task<IActionResult>Index()
        {
            var user=_userManager.Users.SingleOrDefault(x=>x.UserName==User.Identity.Name);
            var pros=await _services.GetAllProducts();
            var group1 = await _services.GetGroups1();           
            var gruop2 = await _services.GetGroups2();
            var group3=await _services.GetGroups3();
            ViewBag.groups1 = group1;
            ViewBag.groups2 = gruop2;
            ViewBag.groups3 = group3;
            if (user!=null)
            {
                ViewBag.user1 = user.UserName;
            }
            return View(pros);
        }

        public async Task<IActionResult> ProductsShop_same(int productId)
        {
            var pro=await _services.GetProducts(productId);
            return View(pro);
        }

        public async Task<IActionResult> productShop_single(int productId)
        {
            var user = _userManager.Users.SingleOrDefault(x => x.UserName == User.Identity.Name);
            var pro=await _services.GetProduct(productId);
            if (pro==null)
            {
                return BadRequest();
            }
            if (user != null)
            {
                ViewBag.user1 = user.UserName;
            }
            var group1 = await _services.GetGroups1();
            var gruop2 = await _services.GetGroups2();
            var group3 = await _services.GetGroups3();
            ViewBag.groups1 = group1;
            ViewBag.groups2 = gruop2;
            ViewBag.groups3 = group3;
            return View(pro);
        }
        [Authorize]
        public async Task<IActionResult> AddProductTOBasket(int productid,int counting )
        {
            var pro = await _services.GetProduct(productid);
            if (counting>pro.Counter)
            {
                return BadRequest();
            }
            var cart =await _services.AddCartid(User.Identity.Name, productid, counting);
            return RedirectToAction("CartShop", "Home", new { username =User.Identity.Name});
        }
        [Authorize]
        public async Task<IActionResult> RemomveItemCart(int itemsid)
        {
            await _services.RemoveItemsCart(itemsid);
            return RedirectToAction("CartShop", new { username = User.Identity.Name });
        }
        [Authorize]
        public async Task<IActionResult> CartShop(string username)
        {
            var cart = await _services.GetCartid(username);
            if (cart==null)
            {
                var carting = new CartId();
                ViewBag.carting = carting;
                var cartitems_temp = new List<CartItems>();
                return View(cartitems_temp);
            }
            var cartitems = await _services.GetCartItems(cart.CarttId);
            ViewBag.carting = cart;
            return View(cartitems);
        }

        public async Task<IActionResult> PayCart(int cartid)
        {
            var cart = await _services.GetCartid(cartid);
            if (cart!=null)
            {
                await _services.PayCarting(cartid);
                return RedirectToAction("Index", "Home");
            }
            return BadRequest();
            
        }


        public async Task<IActionResult> sweetalert ()
        {
            var user = _userManager.Users.SingleOrDefault(x => x.UserName == User.Identity.Name);
            var pros = await _services.GetAllProducts();
            var group1 = await _services.GetGroups1();
            var gruop2 = await _services.GetGroups2();
            var group3 = await _services.GetGroups3();
            ViewBag.groups1 = group1;
            ViewBag.groups2 = gruop2;
            ViewBag.groups3 = group3;
            if (user != null)
            {
                ViewBag.user1 = user.UserName;
            }
            return View(pros);
        }



    }
}