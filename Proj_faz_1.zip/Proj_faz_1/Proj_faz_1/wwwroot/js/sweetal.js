﻿window.onload=function () {
    (async () => {
        const { value: email } = await Swal.fire({
            title: "DONT'T MISS OUT",
            input: "email",
            confirmButtonColor: "black",
            imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2M-0icQcwooO09iL6VjZYGSgB_Ko6w0Sc2QrN9fvDDdp3FFmXKHecpVh78rBEIT66Lig&usqp=CAU',
            imageHeight: 100,
            inputLabel: "Sing up to recive 20% off your next order",
            inputPlaceholder:  "email address"
        });
        if (email) {
            Swal.fire(`Entered email: ${email}`);
        }
    })()
};