﻿using Proj_faz_1.Models;
using Proj_faz_1.Models.context;

namespace Proj_faz_1.Repository
{
    public class Repositories
    {
        private readonly AppDbcontext _context;

        public Repositories(AppDbcontext context)
        {
            _context = context;
        }

        public async Task<List<Products>> GetAllProducts()
        {
            var pros = _context.products.ToList();
            return pros;
        }

        public async Task<List<Products>> GetProducts(int proid)
        {
            var pro = _context.products.SingleOrDefault(x => x.id == proid);
            var pro_same_Regal = _context.products.Where(x => x.Regal_Num == pro.Regal_Num).ToList();
            return pro_same_Regal;
        }

        public async Task<Products> GetProduct(int pro_id)
        {
            var products = _context.products.SingleOrDefault(x => x.id == pro_id);
            return products;
        }


        public async Task<CartId> GetCartid(string username)
        {
            var cart= _context.cartIds.SingleOrDefault(x =>x.UserName==username&&x.isfinal==false);
            return cart;
        }

        public async Task<List<CartItems>> GetCartItems(int cartid)
        {
            return _context.cartItems.Where(x=>x.cartId_FK==cartid).ToList(); 
        }

        public async Task<CartId> GetCartid(int cartid)
        {
            var cart = _context.cartIds.SingleOrDefault(x => x.CarttId== cartid&& x.isfinal == false);
            return cart;
        }

        public async Task<List<group1>> GetGroups1()
        {
            return _context.group1s.ToList();
        }

        public async Task<List<group2>> GetGroups2()
        {
            return _context.group2s.ToList();
        }

        public async Task<List<group3>> GetGroups3()
        {
            return _context.group3s.ToList();
        }

        public async Task<CartId> AddCartid(string username,int proid,int numbers)
        {
            var pro = _context.products.SingleOrDefault(s => s.id == proid);
            if (numbers>pro.Counter)
            {
                return null;
            }
            var cart =await GetCartid(username);
            if (cart==null)
            {
                CartId cart1 = new CartId()
                {
                    UserName = username,
                };

                CartItems cartItems = new CartItems()
                {
                    Coloring = pro.Color,
                    img = pro.img,
                    Numbers = proid,
                    Price = pro.price,
                    ProductName = pro.name,
                    Sizing = pro.size,
                    counting=numbers,
                    cartId_FK=cart1.CarttId
                };
                cart1.TotalPrice = numbers * int.Parse(pro.price);
                _context.cartItems.Add(cartItems);
                cart1.CartItems.Add(cartItems);
                _context.cartIds.Add(cart1);
                _context.SaveChanges();
                return cart1;

            }
            else
            { 
                CartItems cartItems = new CartItems()
                {
                    Coloring = pro.Color,
                    img = pro.img,
                    Numbers = proid,
                    Price = pro.price,
                    ProductName = pro.name,
                    Sizing = pro.size,
                    counting=numbers,
                    cartId_FK=cart.CarttId
                };
                cart.TotalPrice+=numbers * int.Parse(pro.price);
                var cartitmess=_context.cartItems.Add(cartItems);
                cart.CartItems.Add(cartItems);
                _context.SaveChanges();
                return cart;

            }
        }

        public async Task RemoveItemsCart(int itemId)
        {
            var item = _context.cartItems.SingleOrDefault(x => x.CartitemId == itemId);
            _context.cartItems.Remove(item);
            _context.SaveChanges();
            return;
        }

        public async Task<CartId> PayCart(string username)
        {
            var cart = _context.cartIds.SingleOrDefault(x => x.UserName == username);
            cart.isfinal = true;
            _context.SaveChanges();
            return cart;
        }

        public async Task<CartId> PayCarting(int cartid)
        {
            var cart = _context.cartIds.SingleOrDefault(x => x.CarttId== cartid);
            var cartitems=await GetCartItems(cartid);
            foreach (var item in cartitems)
            {
                var products =await GetProduct(item.Numbers);
                if (products.Counter>=item.counting)
                {
                    products.Counter -= item.counting;
                }
                else
                {
                    return null;
                }
            }
            cart.isfinal = true;
            _context.SaveChanges();
            return cart;
        }






    }
}
