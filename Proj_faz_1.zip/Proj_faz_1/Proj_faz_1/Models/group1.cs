﻿using System.ComponentModel.DataAnnotations;

namespace Proj_faz_1.Models
{
    public class group1
    {
        [Key]
        public int id_group1 { get; set; }
        [Required]
        [MaxLength(100)]
        public string name { get; set; }
        [MaxLength(100)]
        public string? Description { get; set; }
        [MaxLength(260)]
        public string? img { get; set; }

        public ICollection<group2> group2s { get; set; }=new List<group2>();


    }
}
