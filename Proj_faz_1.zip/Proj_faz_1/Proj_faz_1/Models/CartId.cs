﻿using System.ComponentModel.DataAnnotations;

namespace Proj_faz_1.Models
{
    public class CartId
    {

        [Key]
        public int CarttId { get; set; }
        [MaxLength(120)]
        public string UserName { get; set; }
        [MaxLength(30)]
        public bool isfinal { get; set; } = false;

        public int? TotalPrice { get; set; }

        public ICollection<CartItems> CartItems { get; set; }=new List<CartItems>();    



    }
}
