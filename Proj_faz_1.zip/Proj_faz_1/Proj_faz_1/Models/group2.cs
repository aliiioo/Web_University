﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proj_faz_1.Models
{
    public class group2
    {
        [Key]
        public int id_group2 { get; set; }
        [Required]
        [MaxLength(100)]
        public string name { get; set; }

        [MaxLength(250)]
        public string? img { get; set; }

        public int id_group1 { get; set; }
        [ForeignKey("id_group1")]
        public group1 group1 { get; set; }

        public ICollection<group3> group3s { get; set; } = new List<group3>();


    }
}
