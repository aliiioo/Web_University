﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proj_faz_1.Models
{
    public class group3
    {
        [Key]
        public int id_group3 { get; set; }
        [Required]
        [MaxLength(100)]
        public string name { get; set; }

        [MaxLength(250)]
        public string? img { get; set; }

        public int id_group2 { get; set; }
        [ForeignKey("id_group2")]
        public group2 group2 { get; set; }
    }
}
