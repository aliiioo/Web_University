﻿using Microsoft.AspNetCore.Identity;

namespace Proj_faz_1.Models
{
    public class Userss: IdentityUser
    {
        public string name { get; set; }
        public string Family { get; set; }
    }
}
