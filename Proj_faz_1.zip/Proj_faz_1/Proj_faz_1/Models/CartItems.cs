﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proj_faz_1.Models
{
    public class CartItems
    {
        [Key]
        public int CartitemId { get; set; }
        [Required]
        [MaxLength(120)]
        public string ProductName { get; set; }
        [MaxLength(20)]
        public string Sizing { get; set; }
        [MaxLength(20)]
        public string Coloring { get; set; }
        public int Numbers { get; set; }
        [MaxLength(20)]
        public string Price { get; set; }
        [MaxLength(120)]
        public string img { get; set; }

        public int counting { get; set; } = 1;

        public int cartId_FK { get; set; }
        [ForeignKey("cartId_FK")]
        public CartId cartId { get; set; }

    }
}
