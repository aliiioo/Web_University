﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Proj_faz_1.Models.context
{
    public class AppDbcontext : IdentityDbContext
    {

        public AppDbcontext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {


        }
        public DbSet<Products> products { get; set; }
        public DbSet<CartId> cartIds { get; set; }
        public DbSet<group1> group1s { get; set; }
        public DbSet<group2> group2s { get; set; }
        public DbSet<group3> group3s { get; set; }
        public DbSet<Userss> users { get; set; }
        public DbSet<CartItems> cartItems   { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            // call the base if you are using Identity service.
            // Important
            base.OnModelCreating(builder);           

            // Code here ...
        }
    }
}
