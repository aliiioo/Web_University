﻿using System.ComponentModel.DataAnnotations;

namespace Proj_faz_1.Models
{
    public class LoginViewModel
    {
        [Required,Display(Name = "نام کاربری")]
        public string UserName { get; set; }

        [Required, Display(Name = "رمز عبور")]
        public string Password { get; set; }

        [Display(Name = "مرا به خاطر بسپار")]
        public bool RememberMe { get; set; }=false;
    }
}
