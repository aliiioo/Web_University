﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proj_faz_1.Models
{
    public class Products
    {
        [Key]
        public int id { get; set; }
        [Required]
        [MaxLength(100)]
        public string name { get; set; }
        public int? Regal_Num { get; set; }
        public int?  score { get; set; }
        [MaxLength(100)]
        public string size { get; set; }
        [MaxLength(100)]
        public string Color { get; set; }
        [MaxLength(100)]
        public string img { get; set; }
        [Required]
        [MaxLength(100)]
        public string Description { get; set; }
        [Required]
        [MaxLength(100)]
        public string price { get; set; }

        public int Counter { get; set; } = 1;

        public int? group_id3 { get; set; }
        [ForeignKey("group_id3")]
        public group3? group3 { get; set; }

    }
}
